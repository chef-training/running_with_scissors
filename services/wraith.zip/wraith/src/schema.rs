table! {
    scans (id) {
        id -> Nullable<Integer>,
        data -> Text,
    }
}
