DROP TABLE scans;
